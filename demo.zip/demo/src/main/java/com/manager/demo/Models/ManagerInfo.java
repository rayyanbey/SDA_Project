package com.manager.demo.Models;

import com.manager.demo.Others.UserInfo;
import jakarta.persistence.*;


@Entity
@Table(name = "managerinfo")
public class ManagerInfo extends UserInfo {

}