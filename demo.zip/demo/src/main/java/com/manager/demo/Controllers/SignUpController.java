package com.manager.demo.Controllers;

public class SignUpController {
}
